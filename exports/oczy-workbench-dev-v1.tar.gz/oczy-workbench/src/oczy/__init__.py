"""Oczy monorepo root package."""

__version__ = "0.1.0"
