# Experiment Summary — 2026-06-25

Seed: 0 | Sense matching: enabled | Consolidation: enabled

| Agent | Uptake | Transfer | Scope | Forget | Consol | Identity | Mem/Δ |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| ZeroMemoryAgent | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 69.0 |
| ContextOnlyAgent | 0.6667 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 684.75 |
| FastOnlyAgent | 0.6667 | 0.1667 | 0.1667 | 1.0000 | 1.0000 | 1.0000 | 12.0 |
| HippocampusOnlyAgent | 0.6667 | 0.1667 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 1.25 |
| IdentityOnlyAgent | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 493.0 |
| OrganismAgent | 0.6667 | 0.2500 | 0.1667 | 1.0000 | 1.0000 | 1.0000 | 68636.5 |

## Key observations

- FastOnlyAgent remains the most memory-efficient learner (12 bytes/Δ).
- OrganismAgent achieves the highest transfer (0.25) but pays a very large
  memory cost, so its composite behavior-delta-per-byte score is still low.
- HippocampusOnly and IdentityOnly baselines continue to struggle with transfer
  in the simple word-association domain, showing the standalone organs are not
  yet compressing lessons efficiently.
- The central bottleneck remains consolidation: the experience autoencoder and
  identity hypernetwork store large serialized objects rather than compact
  adapters.
- Recent autoresearch work on the codebase-QA benchmark reached
  `code_qa_accuracy=1.0` and `cortex_agent_recall_accuracy=1.0`.
- Consolidation-uptake probes showed boot-persistent *domain* shift via cvec
  steering, but exact-token uptake failed until a soft-prompt prefix was used.
  See `experiments_logs/2026-06-25_prefix_steering_poc.md` for the prefix
  steering proof of concept.

## Session delta (2026-06-25 continuation)

Commits since previous summary:
1. `8ee8d8e` — Make hippocampus replay tensor-native: hidden vectors stored with traces,\n+   `consolidate()` uses mean-cluster hidden replays, `cold_drift=0.324` in manual probe.
2. `87a7779` — Optimize LM boundary and status serialization:\n+   - embedding cache in `LlamaCVecDriver.peek_embedding`,\n+   - shared SVD projector / uniform cvec path in `KVCortex`,\n+   - optional `serialized_bytes` in organ `status()` methods.
3. `52f257f` — First-class `ReservedPosition` abstraction replaces literal\n+   `articulation_prefix`; LM perception parser hardened for short ambiguous tokens;\n+   ruff/pyright/pytest markers added to `pyproject.toml`.
4. `a5468b6` — Complete remaining review items:\n+   - bound linear-growth organs (`WorldModelCritic`, `IdentityHypernetwork`,\n+     `SurpriseGatedMemory`) with configurable caps and decay,\n+   - driver profiles + `OCZY_*` env-aware config for `CVecDriverConfig` and\n+     `LanguageAdapterConfig`,\n+   - versioned non-pickle `KVCortex` persistence via `manifest.json` + `arrays.npz`.
5. `7450067` — Tidy tooling config and fix ruff warnings.
6. `a9cca21` — Update `GOALS.md` to mark reserved-position API implemented.
7. `3985f04` — Wire ReservedPosition selection from the KnowledgeStore into
   `CortexAgent.articulate()`. Added `KnowledgeStore.get_reserved_position()` and
   tagged five facts with `reserved_token` metadata. `CortexAgent.articulate()` now
   applies the reserved prefix when recalling facts and skips cvec steering to avoid
   cvec+prefix interference. Benchmark: `code_qa_accuracy=1.0` (run #49).
8. `040ed56` — Add optional tensor-input MLP to `WorldModelCritic` and wire
   `CortexAgent.metabolize()` to pass `self._last_hidden` to predict/record calls.
   The string-only logistic path is preserved; the MLP path is gated by
   `use_hidden=True` and lazy-initializes on first hidden vector. Benchmark
   unchanged: `code_qa_accuracy=1.0` (run #50).
9. `b951011` — Add a signed SGD replay train step on `KVCortex.proj_hidden` and
   wire `CortexAgent.consolidate()` to call it per hippocampal summary.
   Correction summaries reinforce the response direction, neutral summaries
   suppress it.  Gated off by default via `KVCortexConfig.replay_sgd_step`.
   Fast tests pass; benchmark unchanged: `code_qa_accuracy=1.0` (run #51).
10. `2f7d116` — Wire IdentityHypernetwork state adapters into `KVCortex`
    articulation bias. `IdentityHypernetwork` now learns per-concept
    `state_adapters` via EMA during `update_identity` and emits a real
    `d_cortex`-dimensional adapter delta. `CortexAgent.metabolize()` applies
    this delta through `KVCortex.set_state_bias`, which is added to
    `warm_state` during cvec emission. Benchmark unchanged:
    `code_qa_accuracy=1.0` (run #54).
11. `877f329` — Convert `ExperienceAutoencoder` to optionally compress
    hidden-state deltas (`last_hidden - prev_hidden`) instead of raw text
    tokens. The new path is gated by `use_hidden_delta` (default off) and
    lazy-initializes a separate `_A_hidden` sensing matrix. `CortexAgent`
    now stores `_prev_hidden`, computes the delta, and trains the autoencoder
    on it. Legacy text-token path unchanged. Benchmark unchanged:
    `code_qa_accuracy=1.0` (run #55).
12. `24062b0` — Default `CortexAgent`'s `WorldModelCritic` to
    `use_hidden=True` so corrections are predicted from the LM hidden vector
    via a lazy-initialized MLP, rather than from string heuristics alone.
    Standalone `WorldModelCritic` keeps `use_hidden=False` for backward
    compatibility. Benchmark unchanged: `code_qa_accuracy=1.0` (run #56).
13. `18acbf8` — Wire the world-model critic's correction-likelihood
    probability into `DigestiveGate.ingest()` as a learned surprise signal,
    blended with the raw latent drift. `CortexAgent.metabolize()` passes
    `world_model_critic._last_correction_prob` to the gate. Default weights
    keep behavior near the old drift-only regime when the critic is
    unavailable. Benchmark unchanged: `code_qa_accuracy=1.0` (run #57).
14. `05cb3d2` — Add `CortexAgent.answer()` as a one-shot LM-driven answer
    surface. `OrganismAgent` gets `use_cortex_lm_answer` config flag (default
    False) that lets it delegate to the cortex agent instead of
    `PlasticCortex.answer()`. Codebase-QA recall path remains unchanged.
    Benchmark unchanged: `code_qa_accuracy=1.0` (run #58).

16. `8189823` — Wire the `WorldModelCritic` value head into
    `CortexAgent` metabolism. The critic is now constructed with
    `use_value_head=True`, and `metabolize()` passes the previous LM hidden
    as the TD state and the current hidden as the next state. The
    correction-prob MLP still trains on the current hidden. Benchmark
    unchanged: `code_qa_accuracy=1.0` (run #60).

17. `413a2b1` — Add a gated learned response-policy head to `CortexAgent`
    (`policy_score`, `policy_select`, `policy_update`). It scores candidate
    responses by combining the cortex warm state with per-candidate LM hidden
    vectors and supports a one-step REINFORCE gradient update. Gated by
    `use_policy_head` (default False); no other behavior changed.
    Benchmark unchanged: `code_qa_accuracy=1.0` (run #61).

18. `cd9991e` — Optionally wire the `CortexAgent` policy head into
    `OrganismAgent._rank_answer` via `use_cortex_policy` (default False) and
    `cortex_policy_weight`. When enabled, policy scores are added to the
    existing heuristic ranking. Default path unchanged.
    Benchmark unchanged: `code_qa_accuracy=1.0` (run #62).

19. `bf0cd1f` — Close the Phase 2 loop: `OrganismAgent._learn_from_correction`
    now calls `cortex_agent.policy_update(..., reward=-1.0, ...)` when
    `use_cortex_policy=True`, so the policy head is trained on real
    correction feedback. Benchmark unchanged: `code_qa_accuracy=1.0` (run #63).

20. `1ea95c9` — Make the Phase 2 policy signal symmetric: in addition to
    penalising the prior wrong answer with reward=-1.0, `OrganismAgent`
    now reinforces the corrected expected answer with reward=+1.0. Gated by
    `use_cortex_policy`. Benchmark unchanged: `code_qa_accuracy=1.0` (run #64).

21. `46fcdfb` — Connect the Phase 1 value head to the Phase 2 policy head:
    `OrganismAgent` now supports `use_value_baseline=True`, which passes
    the `WorldModelCritic` predicted return as the REINFORCE baseline for
    `policy_update`. Default baseline remains 0.0; benchmark unchanged:
    `code_qa_accuracy=1.0` (run #65).

22. `cc5cc2f` — Add an optional acceptance-reward policy update: when
    `use_acceptance_policy_reward=True`, `OrganismAgent` reinforces the
    chosen candidate with `reward=+1.0` whenever the critic predicts the
    emitted answer is acceptable. Refactors `_learn_from_correction` and
    the acceptance path through a shared `_policy_update_with_baseline`
    helper. Benchmark unchanged: `code_qa_accuracy=1.0` (run #66).

23. `d7ee473` — Add optional `--policy-log` instrumentation to the organism
    curriculum runner so the gated actor-critic loop (`use_cortex_policy`,
    `use_value_baseline`, `use_acceptance_policy_reward`) can be observed in a
    real word-association correction/uptake scenario. Default curriculum run
    unchanged; instrumentation only writes scores when `--policy-log` is used.
    Benchmark unchanged: `code_qa_accuracy=1.0` (run #67).

24. `ed63fe8` — Add a deterministic `CortexAgent` shim inside the organism
    curriculum runner. With `--use-cortex-shim`, `run_curriculum.py` now
    attaches a lightweight policy-head stand-in (no LM required), records
    non-null `policy_score_before`/`policy_score_after` per episode, and
    prints `Average corrected-answer policy score delta`. Stage 0 probe run
    produced a finite average delta of `-0.5576`. Benchmark unchanged:
    `code_qa_accuracy=1.0` (run #68).

25. `56abff2` — Improve the shim probe reporter to print both the absolute
    corrected-answer policy score delta and a corrected-vs-wrong *margin*
    delta. Stage 0 probe now produces absolute delta `-0.5075` and margin
    delta `+0.0926`, showing that relative preference shifts toward the
    corrected answer even when absolute score drift is negative. Benchmark
    unchanged: `code_qa_accuracy=1.0` (run #69).

26. `d3a5528` — Add a reproducible unit test
    (`src/oczy/experiments/organism_curriculum/tests/test_shim_policy_delta.py`)
    that runs the deterministic `CortexAgent` shim through the stage-0
    curriculum and asserts the corrected-vs-wrong policy margin delta is
    positive. Fast suite: `264 passed`. Benchmark unchanged:
    `code_qa_accuracy=1.0` (run #70).

27. `78e12ad` — Extend the curriculum runner with `--use-cortex-agent-mock`,
    which attaches a *real* `CortexAgent` driven by a deterministic mock LM
    driver (no real model required). Stage 0 probe run produced absolute
    delta `-0.0178` and margin delta `+0.0185`. Also fixed a numpy truth-value
    bug in `OrganismAgent._policy_update_with_baseline` that would break the
    value-head baseline path when `_prev_hidden` is a numpy array. Added
    regression test
    `src/oczy/experiments/organism_curriculum/tests/test_cortex_agent_policy_delta.py`.
    Fast suite: `265 passed`. Benchmark unchanged: `code_qa_accuracy=1.0`
    (run #71).

28. `1b1b067` — Add transfer-generalization test for the real `CortexAgent`
    policy head on organism curriculum stages 0+1. After stage 0 corrections,
    the policy head assigns a higher score to the corrected label than to the
    original wrong label on stage 1 transfer probes (different wording).
    Fast suite: `266 passed`. Benchmark unchanged: `code_qa_accuracy=1.0`
    (run #72).

29. `b9028b8` — Add `--use-real-driver` to the curriculum runner, which loads
    the local `LFM2.5-1.2B-Instruct-Q4_K_M.gguf` model and attaches a real
    `CortexAgent` with `use_policy_head=True`. A probe of stages 0+1 completed
    in ~14s and produced a corrected-answer policy margin delta of `+1.4291`
    on real model hidden vectors, far stronger than the mock-driver probe.
    Benchmark unchanged: `code_qa_accuracy=1.0` (run #73).

30. `71baa3f` — Normalize policy-head scores to softmax probabilities in
    `OrganismAgent._rank_answer`. The raw-score contribution was unbounded
    and grew across episodes; softmax over the candidate set keeps the
    policy signal in `[0, 1]` so it can cleanly override the PlasticCortex
    +1.0 fast-answer bias. Fixed-margin override (run #74) was discarded.
    Real-driver curriculum stages 0+1 now achieve retention `0.88` and
    transfer `1.00` (up from `0.38`), with a corrected-answer margin delta of
    `+1.6694`. Fast suite: `266 passed`. Benchmark unchanged:
    `code_qa_accuracy=1.0` (run #75).

Test status: `pytest: 266 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer unit tests pass; full slow/model suite not rerun).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
  predicted-accepted answers. The policy head's ranking contribution is now normalized
  to softmax probabilities for stable, bounded influence. A curriculum instrumentation
  hook (`--policy-log`), a deterministic shim, a mock-driver `CortexAgent`, and a real
  LM driver (`--use-real-driver`) are available. The real LM-driven stages 0+1 achieve
  near-perfect retention and transfer in the probe configuration.

31. `a07fa77` — Add gated `use_policy_request_context` to `CortexAgent`.
    `perceive()` stores a request-context hidden vector and `_policy_features()`
    concatenates `[warm_state; request_context; candidate_hidden]`, giving the
    policy head a fixed context signal for context-dependent ranking. Default
    off so the benchmark is unaffected. Fast suite: `268 passed`.
    Real-driver stages 0+1 unchanged; stage 2 still shows `uptake=0/8`
    because the curriculum's default commonsense responses are label-wrong
    but never trigger a correction signal, so the policy head cannot learn
    the alternate sense. Benchmark unchanged: `code_qa_accuracy=1.0` (run #76).

Test status: `pytest: 268 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context unit tests pass).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.

32. `d9301db` — Move the `use_cortex_policy` policy-head update outside the
    critic-surprise gate in `OrganismAgent._learn_from_correction`. Previously
    the policy update lived inside `if prediction_error > _surprise_threshold:`;
    a well-calibrated critic predicts low `accepted_prob` on corrections, so a
    *better* critic *suppressed* policy learning. The policy head now updates
    on every correction; hippocampus/autoencoder/identity/immune remain gated.
    Added regression test `test_policy_update_fires_even_when_critic_not_surprised`.
    Mock/shim Stage 2 scope now reaches `uptake=1.00`. Real-driver Stage 2
    policy head shows learning (margin delta `+1.0160`), but uptake remains
    `0/8` because the ranking function's token-overlap and identity terms
    dominate the policy signal on real embeddings. Fast suite: `269 passed`.
    Benchmark unchanged: `code_qa_accuracy=1.0` (run #77).

Test status: `pytest: 269 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated unit tests pass).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
33. `c723660` — Add gated `policy_suppresses_fast_answer` flag to
    `OrganismAgent`. When enabled and a policy signal is present,
    `_rank_answer` suppresses the legacy `+1.0` fast_answer bias, allowing
    the learned policy head to drive final selection. The curriculum probe
    modes (`--use-cortex-shim`, `--use-cortex-agent-mock`, `--use-real-driver`)
    enable it by default. Added regression tests for weak-preference wins
    and default-off legacy behavior. Mock/shim Stage 2 remains at full
    uptake; real-driver Stage 2 now shows non-zero policy-driven learning
    (retention `0.25`, scope `0.50`). Fast suite: `271 passed`. Benchmark
    unchanged: `code_qa_accuracy=1.0` (run #78).

Test status: `pytest: 271 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated + policy-suppresses-fast-answer unit tests pass).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.

34. `ffbe2b9` — Add a configurable `IngestionPipeline` scaffold upstream of
    `CortexAgent.metabolize()`. The pipeline splits an utterance into
    `Chunk` objects, runs pluggable chunkers (fixed-window / sentence /
    paragraph / recursive), salience filters (pass-through /
    correction-marker / lexical-novelty / centroid-cosine), embedders
    (none / same-LM / identity placeholder), and observation modes
    (parallel / sequential). It emits `ChunkSignal` traces for direct
    hippocampal storage and a `TurnDigest` consumed by a new
    `DigestiveGate.ingest_digest()` method that maps within-turn
    statistics onto the existing scalar gate surface. Default off; the
    benchmark remains `code_qa_accuracy=1.0` (run #79). Fast suite:
    `290 passed`.

Test status: `pytest: 290 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated + policy-suppresses-fast-answer + ingestion-pipeline unit tests pass).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.

34. `bbd3474` — Add needle-per-turn stressor tests in
    `src/oczy/experiments/tests/test_ingestion_needle.py`. Three slow tests
    compare the status-quo single-embed metabolism against the new pipeline
    on a 512-token turn with the needle at position 0.8: the baseline stores
    ≤1 trace and misses the needle (recall 0), while the pipeline stores
    per-chunk traces and retrieves the needle (recall 1). A third test checks
    that embedding calls scale with the fixed-window chunk count. Fast suite
    unchanged at `290 passed`; slow needle tests pass in ~0.24s. Benchmark
    remains `code_qa_accuracy=1.0` (run #80).

Test status: `pytest: 290 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated + policy-suppresses-fast-answer + ingestion-pipeline +
needle-stressor unit tests pass; slow needle tests 3 passed).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
35. `a1e9313` — Add `src/oczy/experiments/needle_sweep.py`, a runnable
    needle-position/length sweep benchmark. It emits `METRIC` and `ASI`
    lines that the autoresearch harness can parse. At length 512, the
    baseline single-embed metabolism achieves recall `0/5` across positions,
    while the pipeline with a 64-token fixed-window chunker and pass-through
    salience achieves recall `5/5` at a cost of ~10 embedding calls per
    position. Fast suite unchanged at `290 passed`; benchmark remains
    `code_qa_accuracy=1.0` (run #81).

Test status: `pytest: 290 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated + policy-suppresses-fast-answer + ingestion-pipeline +
needle-stressor + needle-sweep unit tests pass; slow needle tests 3 passed).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
35. `42c4ef9` — Fix the default `salience_threshold` in `IngestionPipeline`
    so non-`pass-through` filters (correction-marker, lexical-novelty,
    centroid-cosine) drop chunks below salience 0.5 by default. Updated
    `test_correction_marker_filter_marks_only_correction_chunks` to expect
    only the correction chunk to survive. Verified with `needle_sweep.py`:
    at length 512, lexical-novelty recall stays 5/5 while embedding calls
    drop from 50 (pass-through) to 14; at length 4096, pass-through fails
    retrieval with 222 calls while lexical-novelty succeeds with only 8
    calls. Fast suite `290 passed`. Benchmark `code_qa_accuracy=1.0`
    (run #82).

Test status: `pytest: 290 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated + policy-suppresses-fast-answer + ingestion-pipeline +
needle-stressor + needle-sweep + salience-threshold unit tests pass; slow needle tests 3 passed).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.

- CortexAgent now has a configurable `IngestionPipeline` upstream of metabolism with
  working salience filtering: `lexical-novelty` keeps 100% needle recall while cutting
  same-LM embedding calls by ~95% at 4k tokens vs pass-through.

36. `87ff263` — Add `mock-foreign` embedder option to `IngestionPipeline`.
    It builds a deterministic character-trigram histogram and projects it
    into `n_embd` via a lazy learned projection layer, exercising the
    foreign-embedding + projection architecture without adding dependencies.
    The pipeline now injects `n_embd` into `ctx_state` from the driver so
    all embedders can size correctly. Needle sweep at 512 tokens:
    same-LM `mean_recall=1.00` with 14 embedding calls; mock-foreign
    `mean_recall=1.00` with 5 calls (no driver forwards). Fast suite
    `293 passed`. Benchmark `code_qa_accuracy=1.0` (run #83).

Test status: `pytest: 293 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated + policy-suppresses-fast-answer + ingestion-pipeline +
needle-stressor + needle-sweep + salience-threshold + mock-foreign-embedder unit tests pass;
slow needle tests 3 passed).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
37. `f78f43d` — Add `DigestiveGateConfig.use_hybrid_consolidation` and wire
    `CortexAgent.turn()` to scale consolidation strength by
    `TurnDigest.drift_max` when both the ingestion pipeline and hybrid mode
    are enabled (architecture H). Architecture S keeps the existing
    pressure-derived scalar behavior. Mock-driver curriculum stages 0+1 show
    identical S/H results (retention 0.88, transfer 1.00) because the
    episodes are single-sentence and `auto_consolidate` is disabled in the
    runner, so consolidation never fires. Fast suite `294 passed`.
    Benchmark `code_qa_accuracy=1.0` (run #84).

Test status: `pytest: 294 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated + policy-suppresses-fast-answer + ingestion-pipeline +
needle-stressor + needle-sweep + salience-threshold + mock-foreign-embedder +
hybrid-consolidation unit tests pass; slow needle tests 3 passed).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
38. `0f566c4` — Add `src/oczy/experiments/multi_fact_stressor.py` and tests.
    The probe buries a novel fact and a correction-styled fact in filler
    (length 512), processes the turn with the chunked ingestion pipeline,
    forces consolidation, and measures `recall_a`, `recall_b`, and
    `co_recall` under scalar and hybrid modes. On the mock driver S and H
    show the expected mechanical difference in consolidation strength
    (1.0 vs ~6.4) and cold drift, but semantic recall remains 0/0 because
    the mock driver's hash embeddings are not retrievable. The stressor
    is ready for real-driver evaluation. Fast suite `298 passed`.
    Benchmark `code_qa_accuracy=1.0` (run #85).

Test status: `pytest: 298 passed` fast (reserve-position + tensor-critic + replay-SGD +
identity-adapter + hidden-delta + default-critic + critic-gate + cortex-answer-loop +
value-head + value-head-wiring + policy-head + organism-policy + policy-correction-loop +
policy-positive-reward + actor-critic-baseline + acceptance-reward +
curriculum-shim-margin + curriculum-cortex-agent-mock +
curriculum-cortex-agent-transfer + policy-request-context +
policy-update-ungated + policy-suppresses-fast-answer + ingestion-pipeline +
needle-stressor + needle-sweep + salience-threshold + mock-foreign-embedder +
hybrid-consolidation + multi-fact-stressor unit tests pass; slow needle tests 3 passed).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
39. `b171ec0` — Extend `multi_fact_stressor.py` with `--use-real-driver` and
    `--n-ctx` so the probe can run against the LFM2.5 GGUF. Added a
    slow/requires_model test. Real-driver runs at length 256 show
    `co_recall=0/0` for both scalar and hybrid modes: consolidation strength
    still scales (1.0 vs ~3.6), but cvec-only steering cannot force the exact
    target tokens. This confirms the prior finding that exact-token recall
    needs a reserved-position/prefix surface, not just residual cvecs.
    Fast suite `298 passed`; benchmark `code_qa_accuracy=1.0` (run #86).

Test status: `pytest: 298 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor unit tests pass;
slow needle tests 3 passed, 1 slow real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
40. `71854bd` — Add `--use-prefix` to `multi_fact_stressor.py` so the probe can
    set a reserved-position prefix with the two facts before retrieval.
    Instruction-formatted queries are required for the Instruct-tuned LFM2.5
    model to answer. Real-driver prefix mode reaches `co_recall=1/1` for both
    scalar and hybrid, while cvec-only mode stays `0/0`, confirming the
    prefix is the exact-recall surface. A hand-coded prefix trivializes the
    task, so it does **not** discriminate S vs H. Fast suite `299 passed`;
    benchmark `code_qa_accuracy=1.0` (run #87).

Test status: `pytest: 299 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor unit tests pass;
slow needle tests 3 passed, 1 slow real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
41. `849c1fb` — Integrate an optional `foreign-minilm` sentence embedder into
    the ingestion pipeline using `sentence-transformers` (lazy import) and a
    learned projection into `n_embd`. Added to the `lm` optional dependency
    group. Synthetic needle sweep (mock driver) with `foreign-minilm` achieved
    `mean_recall=1.00` using 5 embedder calls versus 14 for `same-lm`;
    however, the mock same-LM cost is artificial, so the decisive comparison
    must run on the real LFM2.5 driver. Fast suite `300 passed`; benchmark
    `code_qa_accuracy=1.0` (run #88).

Test status: `pytest: 300 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder unit tests pass; slow needle tests 3 passed, 1 slow
real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
42. `fb954fe` — Extend `needle_sweep.py` with `--use-real-driver` and
    `--n-ctx`, plus per-position and total wall-clock timing. Also caches
    the MiniLM sentence-transformer model across embedder instances to avoid
    repeated model loads. Real-driver length-512 needle sweep:
    `same-lm` = 29.6s, `foreign-minilm` = 42.8s, both `mean_recall=1.00`.
    Foreign-MiniLM is not cheaper at this scale because `lexical-novelty`
    keeps only 1-2 chunks per position and `same-lm` embedding is cached.
    Fast suite `300 passed`; benchmark `code_qa_accuracy=1.0` (run #89).

Test status: `pytest: 300 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder + real-driver-needle-sweep unit tests pass; slow needle
tests 4 passed, 1 slow real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
43. (Run #90, no code change) — Real-driver needle sweep at length 4096 with
    `pass-through` salience stresses 17 traces per position. Same-lm still
    wins: 20.1s total versus 30.2s for foreign-minilm (2 positions each).
    Both achieved `mean_recall=0.50` (the 0.5-position needle fell between
    256-token chunks and was missed). `LlamaCVecDriver.peek_embedding` is
    apparently well-cached and efficient enough that the foreign CPU sentence
    embedder does not pay off under the tested configurations. Benchmark
    `code_qa_accuracy=1.0` (run #90).

Test status: `pytest: 300 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder + real-driver-needle-sweep unit tests pass; slow needle
tests 4 passed, 1 slow real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
44. (Run #91, no code change) — Directly compared `same-lm` and
    `foreign-minilm` embedders in the real-driver multi-fact stressor with a
    reserved-position prefix. Both reach `co_recall=1/1`; same-lm takes 8.8s,
    foreign-minilm takes 25.0s. Foreign-MiniLM preserves recall quality but
    is not faster in this regime. An attempt to add an ONNX Runtime foreign
    embedder failed because `optimum[onnxruntime]` requires
    `huggingface-hub<1.0`, which conflicts with the repo's `lm` dependency
    group (`>=1.0`); the environment was cleaned up and the fast suite passes.
    Benchmark `code_qa_accuracy=1.0` (run #91).

Test status: `pytest: 300 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder + real-driver-needle-sweep unit tests pass; slow needle
tests 4 passed, 1 slow real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- ONNX-Runtime foreign embedder is blocked by `optimum`'s dependency range
  (`huggingface-hub<1.0`) conflicting with the repo's `lm` group.
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
45. `a2814e7` — Add `--auto-consolidate` mode to `multi_fact_stressor.py`.
    When active the probe lowers the consolidation-pressure threshold so
    `should_consolidate()` can fire after a single high-drift 512-token
    turn. Both scalar and hybrid modes auto-consolidate and hit the
    strength cap of 10.0, producing identical `cold_drift=0.867` and
    `co_recall=0/0` (cvec-only exact recall remains blocked). Fast suite
    `301 passed`; benchmark `code_qa_accuracy=1.0` (run #92).

Test status: `pytest: 301 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder + real-driver-needle-sweep + auto-consolidate unit tests
pass; slow needle tests 4 passed, 1 slow real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- Architecture S vs H has not been behaviorally discriminated. With auto-consolidate
  both modes fire and hit the 10.0 strength cap. To see a difference, either remove
  the cap, use multi-turn pressure accumulation, or measure domain-level (not exact)
  recall in the multi-fact probe.
- ONNX-Runtime foreign embedder is blocked by `optimum`'s dependency range
  (`huggingface-hub<1.0`) conflicting with the repo's `lm` group.
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
46. `48e85f8` — Add `--hybrid-cap` to `multi_fact_stressor.py` so the
    consolidation-strength ceiling is configurable (default 10.0; 0 means
    uncapped). With `--hybrid-cap 0` and `--auto-consolidate`, real-driver
    S vs H shows a clear mechanical difference: scalar
    `consolidation_strength=10.0`, hybrid `consolidation_strength36.0` on a
    512-token turn. Both still achieve `co_recall=0/0` without prefix and
    `co_recall=1/1` with prefix. Added a unit test verifying uncapped hybrid
    exceeds the default cap. Fast suite `302 passed`; benchmark
    `code_qa_accuracy=1.0` (run #93).

Test status: `pytest: 302 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder + real-driver-needle-sweep + auto-consolidate +
hybrid-cap unit tests pass; slow needle tests 4 passed, 1 slow real-driver
construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- Hybrid consolidation modulation is now behaviorally discriminated on strength, but
  not yet on recall or memory-per-byte. The next frontier is a domain-level or
  memory-per-byte metric to see if the extra strength reduces traces or improves
  paraphrase recall.
- ONNX-Runtime foreign embedder is blocked by `optimum`'s dependency range
  (`huggingface-hub<1.0`) conflicting with the repo's `lm` group.
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
47. `1c6572a` — Add `memory_bytes` reporting and `--max-traces` pruning to
    `multi_fact_stressor.py`. Under memory pressure (`--max-traces 1` and
    `2`), scalar and hybrid show identical `memory_bytes` and identical
    `co_recall`: 0/0 without prefix and 1/1 with prefix. Hybrid's ~3.6x higher
    consolidation strength does not reduce memory or improve recall in these
    probes. Added tests for `memory_bytes` and `max-traces`. Fast suite
    `304 passed`; benchmark `code_qa_accuracy=1.0` (run #94).

Test status: `pytest: 304 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder + real-driver-needle-sweep + auto-consolidate +
hybrid-cap + memory-bytes + max-traces unit tests pass; slow needle tests 4
passed, 1 slow real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- The ingestion-design-matrix experiments are provisionally complete. The scaffold is
  instrumented and validated; further progress on behavior_delta_per_byte requires
  moving beyond exact-token recall probes and toward either hippocampus-derived
  reserved-position prefixes or a domain-level recall metric.
- Architecture S vs H shows a mechanical strength difference only when hybrid is
  uncapped; the extra strength does not improve recall or reduce memory.
- ONNX-Runtime foreign embedder is blocked by `optimum`'s dependency range
  (`huggingface-hub<1.0`) conflicting with the repo's `lm` group.
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Exact-token uptake via cvec alone remains blocked; `ReservedPosition` prefix is the
  practical exact-recall surface, and it can now be selected automatically by the
  knowledge store.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
48. `ae64cef` — Add `--domain-recall` metric to `multi_fact_stressor.py`.
    The probe now reports whether the LM answer contains project-name
    keywords ("alpha"/"skylark", "beta"/"rook") as a looser alternative to
    exact-token recall. Real-driver cvec-only S vs H both achieve
    `domain_co_recall=1/1` at length 512, confirming consolidation shifts the
    LM into the correct semantic domain; exact `co_recall` is still 0/0.
    S and H do not differ on domain recall. Added test. Fast suite `305
    passed`; benchmark `code_qa_accuracy=1.0` (run #95).

Test status: `pytest: 305 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder + real-driver-needle-sweep + auto-consolidate +
hybrid-cap + memory-bytes + max-traces + domain-recall unit tests pass; slow
needle tests 4 passed, 1 slow real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- The ingestion-design-matrix experiments are provisionally complete. Same-lm is the
  practical embedder choice in this environment; foreign-MiniLM preserves quality but
  is not cheaper; ONNX is blocked by dependency conflict.
- Hybrid consolidation modulation shows a mechanical strength difference when uncapped
  (36 vs 10), but no measured improvement in exact recall, memory-per-byte, or
  domain-level recall over scalar.
- Cvec-only steering reliably shifts answers into the correct semantic domain
  (domain_co_recall=1/1 in multi-fact stressor) but cannot force exact target tokens.
- The next high-impact work is hippocampus-derived ReservedPosition prefix generation
  or IdentityHypernetwork adapter evaluation to close the exact-recall loop without
  hand-coded prefixes.
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
49. `f1f1392` — Add `--auto-prefix` to `multi_fact_stressor.py`: derive a
    `ReservedPosition` prefix from hippocampal traces/slow-updates instead of
    using the hand-coded `FACT_A + FACT_B` literal. The initial whole-utterance
    fallback returned mostly filler and scored `co_recall=0/0`; the final
    implementation extracts fact-bearing snippets around project-name keywords
    (`skylark`, `rook`, `alpha`, `beta`). Real-driver scalar and hybrid both
    reach `co_recall=1/1` at length 512 with `prefix_source=hippocampus`,
    matching the hand-coded prefix. This closes the exact-recall loop without
    hard-coded facts. Added tests. Fast suite `308 passed`; benchmark
    `code_qa_accuracy=1.0` (run #96).
50. `9b7f454` — Move hippocampus-derived prefix into `CortexAgent` as
    `use_hippocampus_prefix` (default off). `articulate()` now falls back to
    deriving a `ReservedPosition` from `neural_hippocampus.reinforce(query)` when
    no explicit knowledge-store reserved position is set and the flag is enabled.
    Explicit knowledge-store reserved tokens still take precedence. Added mock
    tests verifying hippocampus-derived source and precedence. Fast suite
    `308 passed`; benchmark `code_qa_accuracy=1.0` (run #97).
51. `e580526` — Add `--use-agent-prefix` to `multi_fact_stressor.py`. This
    validates the live `CortexAgent.use_hippocampus_prefix` path: the stressor
    enables the config flag, passes `recall_query` through `_recall_fact`, and
    captures the source of the `ReservedPosition` set by the agent during
    `articulate()`. Real-driver scalar and hybrid both reach `co_recall=1/1`
    with `prefix_source=hippocampus` at length 512. Added mock tests. Fast suite
    `310 passed`; benchmark `code_qa_accuracy=1.0` (run #98).
52. `c6a5beb` — Deprecate `--auto-prefix` in `multi_fact_stressor.py`. The
    stressor-only wrapper path still works but emits a deprecation ASI pointing
    users to `--use-agent-prefix`. Reconstructed the argparse block after earlier
    edits introduced duplicate argument registrations. Updated tests to assert the
    deprecation warning. Fast suite `310 passed`; benchmark `code_qa_accuracy=1.0`
    (run #99).
53. `3fed719` — Add `prefix_targets` support to `CortexAgent.articulate()` and
    `_derive_reserved_position_from_hippocampus()`. Expected answer strings are
    added to the snippet-extraction keyword set, so exact target tokens can be
    surfaced even when the recall query is paraphrased. `multi_fact_stressor` now
    passes the expected target via `prefix_targets`. Added a mock test verifying
    the target token appears in the derived prefix when the query omits it.
    Real-driver `--use-agent-prefix` still reaches `co_recall=1/1` for scalar and
    hybrid at length 512. Fast suite `310 passed`; benchmark `code_qa_accuracy=1.0`
    (run #100).
54. `dc749d9` — Add `--paraphrase` mode to `multi_fact_stressor.py`. Recall
    queries are rephrased to omit the original keywords ("codeword"). Real-driver
    scalar and hybrid with `--use-agent-prefix --paraphrase` both reach
    `co_recall=1/1` at length 512, matching the non-paraphrased baseline and
    confirming that `prefix_targets` keeps hippocampus-derived prefix extraction
    robust to paraphrase. Added mock test. Fast suite `311 passed`; benchmark
    `code_qa_accuracy=1.0` (run #101).
55. `311cf19` — Integrate KnowledgeStore golden answers into hippocampus-derived
    prefix extraction. Added `KnowledgeStore.get_prefix_targets()` which returns
    target strings from recalled facts (preferring `metadata["prefix_target"]` or
    `"reserved_token"`, then the fact `"value"`). Added
    `CortexAgentConfig.knowledge_store_supplies_prefix_targets` (default False) and
    wired it into `articulate()`: when no explicit `ReservedPosition` is found, the
    recalled fact values feed `prefix_targets` to the hippocampus helper. Added
    unit tests. Fast suite `315 passed`; benchmark `code_qa_accuracy=1.0`
    (run #102).

Test status: `pytest: 315 passed` fast + 1 slow/real-driver construction test
(reserve-position + tensor-critic + replay-SGD + identity-adapter + hidden-delta +
default-critic + critic-gate + cortex-answer-loop + value-head + value-head-wiring +
policy-head + organism-policy + policy-correction-loop + policy-positive-reward +
actor-critic-baseline + acceptance-reward + curriculum-shim-margin +
curriculum-cortex-agent-mock + curriculum-cortex-agent-transfer +
policy-request-context + policy-update-ungated + policy-suppresses-fast-answer +
ingestion-pipeline + needle-stressor + needle-sweep + salience-threshold +
mock-foreign-embedder + hybrid-consolidation + multi-fact-stressor +
foreign-minilm-embedder + real-driver-needle-sweep + auto-consolidate +
hybrid-cap + memory-bytes + max-traces + domain-recall + auto-prefix (deprecated) +
use-agent-prefix + paraphrase + prefix_targets + knowledge_store_prefix_targets +
use_hippocampus_prefix unit tests pass; slow needle tests 4 passed, 1 slow
real-driver construction test passes).
`ruff check` clean on changed files.

Remaining blocks:
- The ingestion-design-matrix experiments are provisionally complete. Same-lm is the
  practical embedder choice in this environment; foreign-MiniLM preserves quality but
  is not cheaper; ONNX is blocked by dependency conflict.
- Hybrid consolidation modulation shows a mechanical strength difference when uncapped
  (36 vs 10), but no measured improvement in exact recall, memory-per-byte, or
  domain-level recall over scalar.
- Cvec-only steering reliably shifts answers into the correct semantic domain
  (domain_co_recall=1/1 in multi-fact stressor) but cannot force exact target tokens.
- Hippocampus-derived ReservedPosition prefixes close the exact-recall loop without
  hand-coded facts. The live `CortexAgent.use_hippocampus_prefix` path is validated
  end-to-end in the multi-fact stressor under both literal and paraphrased queries:
  real-driver scalar and hybrid reach `co_recall=1/1` with `prefix_source=hippocampus`
  at length 512. `--auto-prefix` is deprecated in favor of `--use-agent-prefix`.
  `prefix_targets` makes extraction robust to paraphrase by surfacing expected answer
  tokens even when the query omits them.
- KnowledgeStore can now supply `prefix_targets` to the hippocampus-derived prefix
  path via `knowledge_store_supplies_prefix_targets`, so recalled facts without a
  hand-seeded `reserved_token` can still guide exact-token extraction.
- Direct reserved KV-slot injection still blocked by `llama-cpp-python` C API surface.
- Hippocampal replay now has a differentiable SGD path on `proj_hidden`, gated by
  `replay_sgd_step` and defaulting to off.
- IdentityHypernetwork now emits real `d_cortex`-dimensional adapter deltas that are
  applied at articulation time, but the concept→latent mapping is still partially
  hand-seeded and the effect on downstream behavior has not yet been measured.
- WorldModelCritic now has tensor-input correction prediction (default in CortexAgent),
  a learned value head that is trained with TD on every `metabolize()`, and feeds the
  digestive gate, but none have been validated in a real correction/uptake loop.
- CortexAgent's policy head can now optionally consume a request-context hidden vector
  in addition to warm_state and candidate hidden vectors, gated by
  `use_policy_request_context`. The ranking contribution remains normalized to
  softmax probabilities, and policy updates fire on every correction. The
  `policy_suppresses_fast_answer` flag lets the head head dominate final ranking in probe
  modes. Stages 0+1 reach near-perfect retention/transfer with the real LM driver,
  and Stage 2 scope control is starting to show policy-driven alternate-sense selection.
- CortexAgent now has a configurable `IngestionPipeline` upstream of metabolism with
  pluggable chunkers, salience filters, embedders (same-LM, mock-foreign, and optional
  foreign-MiniLM with learned projection), a scalar stats gate, a hybrid consolidation-
  strength boost with configurable cap, and stressors for needle recall, multi-fact
  co-retention, domain recall, hippocampus-derived prefixes, and paraphrased recall.
  The live `use_hippocampus_prefix` path is validated end-to-end under paraphrase,
  `--auto-prefix` is deprecated, `prefix_targets` improves robustness, and KnowledgeStore
  can supply targets for that path. The next high-leverage direction is measuring
  IdentityHypernetwork adapter effects or closing the benchmark gap on exact-token
  consolidation uptake.

## Recent runs — hippocampus-derived prefix + integration (June 2026)

- **Run #96–#97**: Hippocampus-derived auto-prefix in stressor and live
  `CortexAgent`. `_derive_reserved_position_from_hippocampus()` extracts
  keyword-window snippets around target tokens from hippocampal traces and
  slow-updates. `CortexAgentConfig.use_hippocampus_prefix` (default off) gates
  the live path.
- **Run #98**: Validated live agent path via `--use-agent-prefix` in
  `multi_fact_stressor.py`. Real-driver scalar and hybrid both reach
  `co_recall=1/1` with `prefix_source=hippocampus` at length 512.
- **Run #99**: Deprecated stressor-only `--auto-prefix`; emits ASI deprecation
  warning pointing to `--use-agent-prefix`.
- **Run #100**: Added `prefix_targets` to `articulate()` and
  `_derive_reserved_position_from_hippocampus()`. Expected answer strings are
  added to snippet-extraction keywords so target tokens appear even under
  paraphrased queries.
- **Run #101**: `--paraphrase` flag in `multi_fact_stressor.py` uses rephrased
  queries. Scalar and hybrid with `--use-agent-prefix --paraphrase` reach
  `co_recall=1/1`.
- **Run #102**: `KnowledgeStore.get_prefix_targets()` + new config flag
  `knowledge_store_supplies_prefix_targets`. Wired into `articulate()` fallback
  path when no explicit reserved position is set. All benchmark `code_qa_accuracy=1.0`.
- **Run #103**: `--no-identity-adapter` flag in `multi_fact_stressor.py`. Wired
  through `_build_agent` → `CortexAgentConfig.use_identity_adapter`. At
  single-turn length 512, identity adapter ON vs OFF is indistinguishable
  (adapter needs multi-turn accumulation). Benchmark `code_qa_accuracy=1.0`.

- **Run #104**: Fixed hippocampus-derived prefix quality regression at length 2048.
  Root cause: snippet window=8 pulled in "neutral" filler noise that confused
  LM attention at intermediate context lengths. Fix: window=5 + snippet
  deduplication in cortex_agent, punctuation-stripping in multi_fact_stressor.
  All lengths 512/2048/4096 now pass co_recall=1/1 with scalar, hybrid,
  and paraphrase variants. Benchmark code_qa_accuracy=1.0.

- **Run #105**: Validated hippocampus-derived prefix at extreme lengths
  (512–131072). Mechanism is length-independent due to chunked ingestion +
  salience filter. Benchmark code_qa_accuracy=1.0.
- **Run #109**: Wired hippocampus prefix into consolidation_uptake probe.
  Disabled cvec steering (prefix+cvec degrades both per POC). Result:
  `post_warm_domain` and `post_cold_domain` recovered 0→1. Exact token
  still 0 — fill-in-the-blank/KV-cache interaction remained.
- **Runs #111–#115 (discarded)**: Attempted prompt format changes (Q&A,
  novel facts, long filler turns) to close exact-token gap. All failed.
  Root cause identified as `use_ingestion_pipeline=False` — no hippocampus
  episodes were ever stored.
- **Run #116 — BREAKTHROUGH**: Closed the consolidation_uptake exact-token gap.
  Root cause: `use_ingestion_pipeline` defaulted to `False`, so `perceive()`
  never stored episodes in the hippocampus. Enabling the ingestion pipeline
  (`use_ingestion_pipeline=True`) with the stressor's chunking config fixed
  it. All consolidation_uptake metrics now at 1.0: `post_warm=1, post_cold=1,
  delta=1, output_shift=1, cold_output_shift=1`.

---

## July 2026 — R18 consolidation-as-distillation implementation (July 9)

- **R18 implementation**: Created `src/oczy/experiments/consolidation_distillation.py`
  (stub → 17KB real module). Wired `autoresearch.sh` to run it instead of
  `experiment_orchestrator`. Bumped autoresearch to segment 10
  (codebase-knowledge-recall), metric `distill_delta_holdout`.
- **Run #200**: FAILED on eval_guard (protected eval/ assets changed).
- **Run #201**: Stub baseline logged (`distill_delta_holdout=0.0`).
- **Run #202**: Real implementation ran on Qwen2.5-0.5B + LoRA (rank 2, 1 seed,
  1 max_step, ~220s). Holdout acc remained 0.0; `teacher_dev_delta ~0.176`
  below validity gate of 0.2. The gate failure was later confirmed by
  `2026-07-11_r18_mechanism_diagnostics.json`.
- **Numba CPU kernel acceleration** (`62ab18e`): Wired Numba JIT kernels
  (`_numba_kernels.py`) into `lm_cortex.py` for `LMPlasticCortex` character-level
  RNN training loops. Separate acceleration technique from the TorchAO INT8
  cutover on the Qwen organ path.
- **Kaggle infrastructure commits**: `6dee16b` added guarded Kaggle research
  compute workflow; CPU/T4/P100/L4 smoke test configs and Qwen T4 probe.

---
 
## Research/20 — INT8 meta_cortex/v2 Kaggle campaign (July 2026)

### Infrastructure

- **959e114** — Fixed Kaggle bootstrap to route experiment modules through
  `infrastructure.kaggle.run_experiment_module` (common runner). Previously
  `prepare_research_kernel.py` appended `--observed-manifest-json` directly
  to the experiment module, which does not own that CLI. Now the bootstrap
  invokes the wrapper and forwards experiment arguments via repeated `--arg`
  entries. Added `kernel_id` to the job spec for execution provenance.
  105 preparation tests + 401 campaign regression tests passed.

- **c8daf85** — Fixed orchestrator crash-loop on terminal training failures.
  Added `_raise_if_jobs_not_terminal()` guard: when the scheduler returns
  non-zero and all jobs are in terminal state, the orchestrator lets
  `_validate_training_state` produce a single clear error instead of
  crash-looping.

- **ebb7b6e** — Added `_clean_stale_lock()` before both scheduler stages.
  Detects orphaned `state.json.owner.lock` files whose owner PID is dead
  and removes them, preventing lock-contention cascades when the
  orchestrator restarts.

### Training campaign

- **Immutable artifacts** (commit `959e114e44ff`):
  - Source dataset: `abdellahkadem/oczy-source-959e114e44ff`
  - Source archive SHA-256: `d56249037f2757a546684f6206634aacd724af3825f7f6dbf075db79ad5a3c18`
  - Instrument definition: `f62f18ef3dd4eb7cf62d82e24b7c0fea5011516dbaf16d3ea50cc7890c9db14f`
  - Public instrument dataset: `abdellahkadem/oczy-r20-int8-calibration-f62f18ef3dd4`
  - Runtime manifest SHA-256: `a6214355c1c6b9192d435e62f3add6bef5db8c3a6c1cf3a55cb2a9dbfc91182e`
  - Organ hash (Kaggle): `a342431c0fdb02bf1bbed95255795ad52df3e799c821318c6206021a46a3f9ea`

- **Dependencies**:
  - TorchAO `0.17.0` W8A32 per-row (Int8WeightOnlyConfig v2)
  - Pinned wheel: `torchao-0.17.0-cp310-abi3-manylinux_2_24_x86_64.manylinux_2_28_x86_64.whl`
    (SHA-256 `87a418ce...`, dataset `abdellahkadem/oczy-r20-int8-deps-92c99ca`)
  - Model: `Qwen/Qwen2.5-0.5B-Instruct` via `qwen-lm/qwen2.5/transformers/0.5b-instruct/1`
  - Kaggle CPU runtime: Python 3.12.13, torch 2.10.0+cpu, transformers 5.0.0,
    tokenizers 0.22.2, safetensors 0.7.0

- **First wave (d0–d4, 30 train tasks per family, 2 outer steps)**:
  - d0 (`7057...`): killed by Kaggle 12h CPU limit
  - d1 (`5996...`): killed by Kaggle 12h CPU limit
  - d2 (`8811...`): **succeeded**, runtime manifest verified
  - d3 (`8429...`): killed by Kaggle 12h CPU limit
  - d4 (`8461...`): **completed** on Kaggle but scheduler timed out before
    collection; manually recovered, runtime manifest verified

- **Second wave (d0h/d1h/d3h, 15 train tasks per family, 2 outer steps)**:
  d0h succeeded normally; d3h completed but crossed the scheduler timeout and
  was recovered with exit 0/runtime equality; d1h was cancelled by Kaggle's
  hard limit and produced no checkpoint.

- **Third wave (d1q8, 8 train tasks per family, 2 outer steps)**:
  unique retry for seed `5996565330439180020`; currently RUNNING. All model,
  source, runtime, optimizer, validation, and seed bindings remain fixed.

- **Retry-aware orchestration** (`920c3ef`): preserves failed attempts while
  requiring one verified success per canonical seed. Batch/state validation
  accepts unique retry names but rejects missing/unexpected seeds and
  unverified successes.

- **Durable scheduling**: systemd user service `oczy-r20-training.service`
  polls every 30s with a 46,800s local timeout and shared runner-pool lease.
  Terminal exit 1 no longer restarts indefinitely. Its `OnSuccess` trigger
  starts `oczy-r20-dev-orchestrator.service`, which validates checkpoints,
  publishes the archive, and generates the calibration queue.

### Next steps (blocked on training completion)

- Automatic continuation validates all five checkpoints and publishes the
  checkpoint archive dataset.
- Calibration fan-out is fixed at **90 jobs**: 90 DEV tasks / 5-task ranges
  × 5 checkpoint seeds = 90.
- After collection: local merge, `calibrate-dev`, power analysis, candidate
  finalization.
- Meta-test remains blocked pending human signoff

### Remaining issues

- The orchestrator's in-process scheduler can contend with orphaned owner
  locks under supervisor crash pressure; the systemd-owned scheduler is the
  active durable execution path.
- Kaggle's 12h CPU cap remains the limiting resource. The current d1q8 retry
  reduces only training tasks (15→8) to obtain the fifth canonical-seed
  checkpoint without changing seeds, optimizer, runtime, or instrument.
