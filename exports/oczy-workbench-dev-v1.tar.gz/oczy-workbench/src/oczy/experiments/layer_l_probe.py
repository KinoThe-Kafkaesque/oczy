"""Layer-L hidden extraction probe (Experiment 03).

Measures whether feeding ``KVCortex.observe()`` real residuals at mid/upper
layers produces more semantically separable ``warm_state`` vectors than the
current final-layer mean-pool.  Follows the Experiment 03 spec and aligns
with ``lanes/lane_03.py`` for layer indices and pooling conditions.

Modes:
  - ``--driver mock``: fast, deterministic, semantics-free floor using
    norm-matched random vectors.
  - ``--driver real``: loads ``LiquidAI/LFM2.5-1.2B-Instruct`` via transformers
    and computes layer-L silhouettes.

On any real-driver failure, the probe fails closed: it emits an actionable
``ASI real_driver=failed`` diagnostic (error type, message, traceback, and a
remediation hint) and exits nonzero rather than falling back to mock metrics.
Use ``--driver mock`` explicitly for the deterministic floor.
"""

from __future__ import annotations

import argparse
import math
import os
import sys
import traceback
from typing import Any

import numpy as np

# ---------------------------------------------------------------------------
# Concept battery (matches lanes/lane_03.py)
# ---------------------------------------------------------------------------

_CONCEPTS: dict[str, list[str]] = {
    "paris": [
        "The capital of France is Paris.",
        "France's capital city is Paris.",
        "Paris is the capital of France.",
    ],
    "water": [
        "Water boils at 100 degrees Celsius.",
        "The boiling point of water is 100C.",
        "At sea level, water boils at 100 degrees.",
    ],
    "gravity": [
        "Gravity pulls objects toward Earth.",
        "Things fall because of gravity.",
        "Earth's gravity attracts masses downward.",
    ],
}

_D_EMBD = 2048
_N_LAYERS = 16
_N_HIDDEN_STATES = _N_LAYERS + 1  # embedding + one per block


# ---------------------------------------------------------------------------
# Cosine + silhouette helpers
# ---------------------------------------------------------------------------


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def _silhouette(warm_by_concept: dict[str, list[np.ndarray]]) -> float | None:
    """Cosine silhouette = mean intra-concept cosine - mean inter-concept cosine."""
    concepts = list(warm_by_concept)
    intra: list[float] = []
    inter: list[float] = []
    for i, ci in enumerate(concepts):
        si = warm_by_concept[ci]
        for a_idx in range(len(si)):
            for b_idx in range(a_idx + 1, len(si)):
                intra.append(_cosine(si[a_idx], si[b_idx]))
        for cj in concepts[i + 1 :]:
            sj = warm_by_concept[cj]
            for a_idx in range(len(si)):
                for b_idx in range(len(sj)):
                    inter.append(_cosine(si[a_idx], sj[b_idx]))
    if not intra or not inter:
        return None
    return float(np.mean(intra) - np.mean(inter))


# ---------------------------------------------------------------------------
# Mock driver
# ---------------------------------------------------------------------------


def _mock_hidden_vectors(
    layer_idx: int, *, rng: np.random.RandomState | None = None
) -> np.ndarray:
    """Return a deterministic, norm-matched random vector for mock smoke runs."""
    if rng is None:
        rng = np.random.RandomState(0)
    vec = rng.standard_normal(_D_EMBD).astype(np.float32)
    target_norm = 1.0 + 0.05 * layer_idx
    vec /= np.linalg.norm(vec)
    return (vec * target_norm).astype(np.float32)


def _mock_probe() -> dict[str, float]:
    """Fast semantics-free probe: random floor + layer-scaled random vectors."""
    from plastic_cortex.kv_cortex import KVCortex, KVCortexConfig

    all_phrases = [p for ps in _CONCEPTS.values() for p in ps]
    rng = np.random.RandomState(0)

    def _hidden_for(layer_idx: int) -> list[np.ndarray]:
        return [_mock_hidden_vectors(layer_idx, rng=rng) for _ in all_phrases]

    def _sil_for(layer_idx: int) -> float | None:
        warm_by_concept: dict[str, list[np.ndarray]] = {}
        for concept, phrases in _CONCEPTS.items():
            cortex = KVCortex(
                KVCortexConfig(
                    d_cortex=128,
                    d_embd=_D_EMBD,
                    n_layers=_N_LAYERS,
                    seed=0,
                )
            )
            cortex.reset_warm_to_zeros()
            states: list[np.ndarray] = []
            phrase_vectors = _hidden_for(layer_idx)
            for i in range(len(phrases)):
                states.append(cortex.observe(phrase_vectors[i], correction_signal=0.0))
            warm_by_concept[concept] = states
        return _silhouette(warm_by_concept)

    silhouettes: dict[str, float] = {
        "R_random": 0.0,
        "last_L9": _sil_for(9) or 0.0,
        "last_L13": _sil_for(13) or 0.0,
        "last_L15": _sil_for(15) or 0.0,
        "maxpool_L14": _sil_for(14) or 0.0,
        "mean_L14": _sil_for(14) or 0.0,
    }
    return silhouettes


# ---------------------------------------------------------------------------
# Real driver
# ---------------------------------------------------------------------------


def _hf_probe() -> dict[str, float] | None:
    """Load the HF LFM2.5-1.2B-Instruct twin and compute layer-L silhouettes."""
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    from plastic_cortex.kv_cortex import KVCortex, KVCortexConfig

    # Prefer explicit env (set by the Kaggle bootstrap or a local user).
    # Fall back to the canonical HF hub id only outside remote/offline mode.
    env_hf_dir = os.environ.get("OCZY_HF_MODEL_DIR")
    offline = (
        os.environ.get("OCZY_REMOTE_CPU_ONLY") == "1"
        or os.environ.get("HF_HUB_OFFLINE") == "1"
        or os.environ.get("TRANSFORMERS_OFFLINE") == "1"
    )
    model_name = env_hf_dir if env_hf_dir else "LiquidAI/LFM2.5-1.2B-Instruct"
    load_kwargs: dict[str, Any] = {}
    if offline or env_hf_dir is not None:
        load_kwargs["local_files_only"] = True
        load_kwargs["trust_remote_code"] = False

    tokenizer = AutoTokenizer.from_pretrained(model_name, **load_kwargs)
    assert tokenizer is not None
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.bfloat16,
        output_hidden_states=True,
        **load_kwargs,
    )
    model.eval()

    all_phrases = [p for ps in _CONCEPTS.values() for p in ps]
    phrase_hiddens: dict[str, list] = {}
    with torch.no_grad():
        for phrase in all_phrases:
            enc = tokenizer(phrase, return_tensors="pt")
            out = model(**enc)
            hs = out.hidden_states
            if hs is None or len(hs) != _N_HIDDEN_STATES:
                return None
            phrase_hiddens[phrase] = [
                h[0].to(torch.float32).numpy() for h in hs
            ]

    def _last_token(seq_arr: np.ndarray) -> np.ndarray:
        return seq_arr[-1, :]

    def _mean_pool(seq_arr: np.ndarray) -> np.ndarray:
        return seq_arr.mean(axis=0)

    def _max_pool(seq_arr: np.ndarray) -> np.ndarray:
        return seq_arr.max(axis=0)

    # Align with lanes/lane_03.py: hidden_states tuple index = layer+1.
    conditions = [
        ("last_L9", 10, _last_token),
        ("last_L13", 14, _last_token),
        ("last_L15", 16, _last_token),
        ("maxpool_L14", 15, _max_pool),
        ("mean_L14", 14, _mean_pool),
        ("final_meanpool", 16, _mean_pool),
    ]

    silhouettes: dict[str, float] = {
        "R_random": 0.0,
    }
    for label, idx, pool in conditions:
        warm_by_concept: dict[str, list[np.ndarray]] = {}
        for concept, phrases in _CONCEPTS.items():
            cortex = KVCortex(
                KVCortexConfig(
                    d_cortex=128,
                    d_embd=_D_EMBD,
                    n_layers=_N_LAYERS,
                    seed=0,
                )
            )
            cortex.reset_warm_to_zeros()
            states: list[np.ndarray] = []
            for phrase in phrases:
                vec = pool(phrase_hiddens[phrase][idx])
                if vec.shape[0] != _D_EMBD:
                    return None
                states.append(cortex.observe(vec, correction_signal=0.0))
            warm_by_concept[concept] = states
        s = _silhouette(warm_by_concept)
        silhouettes[label] = 0.0 if s is None else s

    # Best-effort GGUF final-layer mean-pool baseline.
    try:
        from llama_cpp import Llama

        from oczy.experiments.multi_fact_stressor import _resolve_gguf_path
        from oczy.lm.cvec_driver import LlamaCVecDriver

        resolved = _resolve_gguf_path()
        if resolved is not None:
            llm = Llama(
                model_path=str(resolved),
                n_ctx=512,
                n_threads=4,
                embedding=True,
                verbose=False,
            )
            driver = LlamaCVecDriver(llm)
            if driver.n_embd == _D_EMBD:
                gguf_warm: dict[str, list[np.ndarray]] = {}
                ok = True
                for concept, phrases in _CONCEPTS.items():
                    cortex = KVCortex(
                        KVCortexConfig(
                            d_cortex=128,
                            d_embd=driver.n_embd,
                            n_layers=_N_LAYERS,
                            seed=0,
                        )
                    )
                    cortex.reset_warm_to_zeros()
                    states = []
                    for phrase in phrases:
                        emb = driver.peek_embedding(
                            phrase, last_token_only=False
                        )
                        if emb.shape[0] != driver.n_embd:
                            ok = False
                            break
                        states.append(
                            cortex.observe(emb, correction_signal=0.0)
                        )
                    if not ok:
                        break
                    gguf_warm[concept] = states
                if ok:
                    s = _silhouette(gguf_warm)
                    if s is not None:
                        silhouettes["final_meanpool"] = s
    except Exception:
        pass

    return silhouettes


# ---------------------------------------------------------------------------
# Metric computation
# ---------------------------------------------------------------------------


def _compute_gap(silhouettes: dict[str, float]) -> dict[str, Any]:
    """Return primary metric and per-condition gap info."""
    final = silhouettes.get("final_meanpool")
    mid_layer_labels = [
        k
        for k in silhouettes
        if k not in ("R_random", "final_meanpool")
    ]
    mid_values = [silhouettes[k] for k in mid_layer_labels]
    max_mid = max(mid_values) if mid_values else 0.0
    gap = (max_mid - final) if final is not None else 0.0
    return {
        "gap": gap,
        "max_mid": max_mid,
        "final": final,
        "mid_labels": mid_layer_labels,
    }


# ---------------------------------------------------------------------------
# Main / CLI
# ---------------------------------------------------------------------------


def _report_real_driver_failure(
    exc: Exception | None, tb: str | None
) -> None:
    """Emit an actionable diagnostic when the real HF driver cannot produce metrics.

    Called only on the ``--driver real`` path when ``_hf_probe`` raises or
    returns ``None``.  Prints structured ``ASI`` lines so a caller can
    distinguish a genuine real-driver failure from a completed scientific run,
    plus a remediation hint.  Never falls back to mock metrics.
    """
    print("ASI real_driver=failed")
    if exc is not None:
        print(f"ASI real_driver_error_type={type(exc).__name__}")
        msg = str(exc).strip().replace("\n", " ")
        if msg:
            print(f"ASI real_driver_error_message={msg}")
        if tb and tb.strip() != "NoneType: None":
            print("ASI real_driver_traceback:")
            for line in tb.rstrip().splitlines():
                print(f"  {line}")
    else:
        print(
            "ASI real_driver_error_message=_hf_probe returned no result "
            "(hidden-state length/shape mismatch or missing layers)"
        )
    print(
        "ASI real_driver_hint=verify the LFM2.5-1.2B-Instruct snapshot is "
        "available (OCZY_HF_MODEL_DIR or HF cache), that torch/transformers "
        "are installed and output_hidden_states is supported, then retry; "
        "or run with --driver mock for the deterministic floor."
    )

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Layer-L hidden extraction probe"
    )
    parser.add_argument(
        "--driver",
        choices=["mock", "real"],
        default="mock",
        help="mock = fast deterministic floor; real = HF LFM2.5-1.2B-Instruct",
    )
    args = parser.parse_args(argv)

    if args.driver == "real":
        probe_exc: Exception | None = None
        probe_tb: str | None = None
        try:
            silhouettes = _hf_probe()
        except Exception as exc:  # fail closed, not fallback
            silhouettes = None
            probe_exc = exc
            probe_tb = traceback.format_exc()
        if silhouettes is None:
            _report_real_driver_failure(probe_exc, probe_tb)
            return 1
    else:
        silhouettes = _mock_probe()

    result = _compute_gap(silhouettes)
    gap = result["gap"]

    if math.isnan(gap):
        gap = 0.0
    print(f"METRIC layer_l_silhouette_gap={gap}")
    for label, value in silhouettes.items():
        print(f"ASI warm_sep_silhouette_{label}={value}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
